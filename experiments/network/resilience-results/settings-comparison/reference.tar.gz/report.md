# Network failure scenario report

Contract v2: resilience acceptance is separate from the unchanged normal serving SLO and legacy acceptance checks. A resilience PASS never erases failed requests.

Source: `dfee96b5660de567c000723159190b4eeb59c9da`. Environment: Linux-7.0.12-linuxkit-aarch64-with-glibc2.39; Python 3.12.3. Seed: **101**.

Workload: **3 workers, 6.0 RPS, concurrency 32, 512 input / 16 output events**. Phases: 10s healthy → 12s fault → 20s recovery. Scenarios execute sequentially with fresh processes.

Timing source: **model-derived**. Settings: `{"backend": "vllm", "backend_version": "0.24.0", "batch_size": 1, "model": "meta-llama/Meta-Llama-3.1-8B", "pp": 1, "system": "h100_sxm", "tp": 1}`. Model-derived schedules are estimates, not measured GPU serving. Each replay worker runs one request at a time; no continuous batching or KV-cache model.

Normal SLO: complete, TTFT ≤250.0ms, every output gap ≤100.0ms, total ≤2000.0ms. Scenario-specific resilience contracts are shown below; normal-SLO breaches remain visible.

Inputs, source files, binaries and case evidence have SHA-256 records in `suite.json`. Metrics below are recomputed from raw requests/attempts and checked against each original report.

[Recorded evidence bundle](evidence.tar.gz). Extract it to inspect the case files below or regenerate this report without running traffic.

Routing: first-output timeout 1.0s; options `{"cooldown_s": 1.0, "failure_threshold": 0, "least_inflight_retries": false, "probe_when_all_open": false}`.

## Overview

Fault-phase metrics; latency percentiles only describe received output. Failures/drops remain in completion and SLO denominators. N/A means no observed output, not zero latency.

| Scenario | Resilience | Normal SLO | Legacy contract | Completed (all offered) | Fault SLO % | Fault TTFT p95 ms | Fault gap p99 ms | Fault goodput RPS |
|---|---|---|---|---:|---:|---:|---:|---:|
| baseline | PASS | PASS | PASS | 252/252 | 100.00 | 16.67 | 7.70 | 6.00 |
| worker-stall | FAIL | FAIL | FAIL | 252/252 | 68.06 | 1017.04 | 7.61 | 4.08 |
| worker-flapping | FAIL | FAIL | FAIL | 252/252 | 87.32 | 1014.81 | 7.64 | 5.17 |

## baseline

**PASS**. Fault: `No proxy rule.`

Normal serving SLO: **PASS**; legacy acceptance: **PASS**.

Frozen fault contract: `{"body_bytes_bound": 4110, "budget_basis": "Normal contract; attributable upstream failures may fail over.", "cancellation_ms": 500, "deadline_slack_ms": 100, "fault_slo": {"gap_ms": 100.0, "total_ms": 2000.0, "ttft_ms": 250.0}, "frame_bytes_bound": 256, "http_overhead_bytes_bound": 1024, "quiet_ms": 0, "scenario": "baseline", "version": 2}`

| Metric | Healthy | Fault (change) | Recovery (change) |
|---|---:|---:|---:|
| completion_pct | 100.00 | 100.00 (+0.00 pp) | 100.00 (+0.00 pp) |
| compliance_pct | 100.00 | 100.00 (+0.00 pp) | 100.00 (+0.00 pp) |
| ttft_p95_ms | 16.18 | 16.67 (+3.0%) | 16.92 (+4.6%) |
| gap_p99_ms | 7.57 | 7.70 (+1.7%) | 7.65 (+1.1%) |
| goodput_rps | 6.00 | 6.00 (-0.0%) | 6.00 (-0.0%) |

All offered: **252**; completed: **252**; boundary/guard requests retained: **0**.

Recovery stability window starts +0.00s after removal; confirmed +5.00s (30 requests). This is not node restart time.

All required checks passed.

Evidence in bundle: `01-baseline/report.txt`, `01-baseline/config.json`, `01-baseline/requests.jsonl`.

## worker-stall

**FAIL**. Fault: `{"action": "stall", "direction": "response", "seed": 101, "target": "worker-1"}`

Normal serving SLO: **FAIL**; legacy acceptance: **FAIL**.

Frozen fault contract: `{"body_bytes_bound": 4110, "budget_basis": "Normal contract; attributable upstream failures may fail over.", "cancellation_ms": 500, "deadline_slack_ms": 100, "fault_slo": {"gap_ms": 100.0, "total_ms": 2000.0, "ttft_ms": 250.0}, "frame_bytes_bound": 256, "http_overhead_bytes_bound": 1024, "quiet_ms": 0, "scenario": "worker-stall", "version": 2}`

| Metric | Healthy | Fault (change) | Recovery (change) |
|---|---:|---:|---:|
| completion_pct | 100.00 | 100.00 (+0.00 pp) | 100.00 (+0.00 pp) |
| compliance_pct | 100.00 | 68.06 (-31.94 pp) | 100.00 (+0.00 pp) |
| ttft_p95_ms | 16.98 | 1017.04 (+5890.0%) | 16.99 (+0.1%) |
| gap_p99_ms | 7.71 | 7.61 (-1.3%) | 7.57 (-1.8%) |
| goodput_rps | 6.07 | 4.08 (-32.7%) | 5.95 (-2.0%) |

All offered: **252**; completed: **252**; boundary/guard requests retained: **13**.

Recovery stability window starts +0.00s after removal; confirmed +5.00s (30 requests). This is not node restart time.

Failed checks:

- fault: TTFT p95 ms: 1017.04; required <= 600.00.
- fault: added TTFT p95 ms: 1000.06; required <= 350.00.

Evidence in bundle: `02-worker-stall/report.txt`, `02-worker-stall/config.json`, `02-worker-stall/requests.jsonl`.

## worker-flapping

**FAIL**. Fault: `{"action": "stall", "direction": "response", "seed": 101, "target": "worker-1"}`

Normal serving SLO: **FAIL**; legacy acceptance: **FAIL**.

Frozen fault contract: `{"body_bytes_bound": 4110, "budget_basis": "Normal contract; attributable upstream failures may fail over.", "cancellation_ms": 500, "deadline_slack_ms": 100, "fault_slo": {"gap_ms": 100.0, "total_ms": 2000.0, "ttft_ms": 250.0}, "frame_bytes_bound": 256, "http_overhead_bytes_bound": 1024, "quiet_ms": 0, "scenario": "worker-flapping", "version": 2}`

| Metric | Healthy | Fault (change) | Recovery (change) |
|---|---:|---:|---:|
| completion_pct | 100.00 | 100.00 (+0.00 pp) | 100.00 (+0.00 pp) |
| compliance_pct | 100.00 | 87.32 (-12.68 pp) | 100.00 (+0.00 pp) |
| ttft_p95_ms | 17.17 | 1014.81 (+5809.0%) | 17.36 (+1.1%) |
| gap_p99_ms | 7.66 | 7.64 (-0.2%) | 7.79 (+1.8%) |
| goodput_rps | 6.08 | 5.17 (-14.9%) | 6.00 (-1.2%) |

All offered: **252**; completed: **252**; boundary/guard requests retained: **13**.

Recovery stability window starts +0.00s after removal; confirmed +5.00s (30 requests). This is not node restart time.

Failed checks:

- fault: TTFT p95 ms: 1014.81; required <= 600.00.
- fault: added TTFT p95 ms: 997.63; required <= 350.00.

Evidence in bundle: `03-worker-flapping/report.txt`, `03-worker-flapping/config.json`, `03-worker-flapping/requests.jsonl`.

## Reproduction boundaries

The recipe, order, seed and report calculation are fixed. Regenerating from unchanged saved evidence with this source produces identical Markdown/JSON. Fresh TCP runs will have different timing samples because of CPU scheduling, buffering and TCP chunking; a seed does not make live networking deterministic. Compare distributions and verdicts, not bitwise-equal live timings. Each scenario here is one run, not a confidence interval.

The pre-fault deadline guard and control-boundary exclusions are explicit; those requests are still in all-offered totals. Inter-output events are not necessarily individual tokens. No natural failure likelihood, EC2 performance or GPU throughput is inferred.
