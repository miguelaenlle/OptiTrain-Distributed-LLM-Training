# Network failure scenario report

Contract v2: resilience acceptance is separate from the unchanged normal serving SLO and legacy acceptance checks. A resilience PASS never erases failed requests.

Source: `3bd77a6`. Environment: Linux-7.0.12-linuxkit-aarch64-with-glibc2.39; Python 3.12.3. Seed: **42**.

Workload: **3 workers, 6.0 RPS, concurrency 32, 512 input / 16 output events**. Phases: 10s healthy → 12s fault → 20s recovery. Scenarios execute sequentially with fresh processes.

Timing source: **model-derived**. Settings: `{"backend": "vllm", "backend_version": "0.24.0", "batch_size": 1, "model": "meta-llama/Meta-Llama-3.1-8B", "pp": 1, "system": "h100_sxm", "tp": 1}`. Model-derived schedules are estimates, not measured GPU serving. Each replay worker runs one request at a time; no continuous batching or KV-cache model.

Normal SLO: complete, TTFT ≤250.0ms, every output gap ≤100.0ms, total ≤2000.0ms. Scenario-specific resilience contracts are shown below; normal-SLO breaches remain visible.

Inputs, source files, binaries and case evidence have SHA-256 records in `suite.json`. Metrics below are recomputed from raw requests/attempts and checked against each original report.

[Recorded evidence bundle](evidence.tar.gz). Extract it to inspect the case files below or regenerate this report without running traffic.

Routing: first-output timeout 0.2s; options `{"cooldown_s": 1.0, "failure_threshold": 2, "least_inflight_retries": true}`.

## Overview

Fault-phase metrics; latency percentiles only describe received output. Failures/drops remain in completion and SLO denominators. N/A means no observed output, not zero latency.

| Scenario | Resilience | Normal SLO | Legacy contract | Completed (all offered) | Fault SLO % | Fault TTFT p95 ms | Fault gap p99 ms | Fault goodput RPS |
|---|---|---|---|---:|---:|---:|---:|---:|
| baseline | FAIL | FAIL | FAIL | 252/252 | 100.00 | 24.37 | 9.03 | 6.00 |
| combined-path-delay | FAIL | FAIL | FAIL | 252/252 | 93.06 | 459.71 | 12.54 | 5.59 |
| fleet-stall | FAIL | FAIL | FAIL | 178/252 | 0.00 | N/A | N/A | 0.00 |
| slow-client-upload | FAIL | FAIL | FAIL | 182/252 | 1.39 | 1956.11 | 12.53 | 0.08 |

## baseline

**FAIL**. Fault: `No proxy rule.`

Normal serving SLO: **FAIL**; legacy acceptance: **FAIL**.

Frozen fault contract: `{"body_bytes_bound": 4110, "budget_basis": "Normal contract; attributable upstream failures may fail over.", "cancellation_ms": 500, "deadline_slack_ms": 100, "fault_slo": {"gap_ms": 100.0, "total_ms": 2000.0, "ttft_ms": 250.0}, "frame_bytes_bound": 256, "http_overhead_bytes_bound": 1024, "quiet_ms": 0, "scenario": "baseline", "version": 2}`

| Metric | Healthy | Fault (change) | Recovery (change) |
|---|---:|---:|---:|
| completion_pct | 100.00 | 100.00 (+0.00 pp) | 100.00 (+0.00 pp) |
| compliance_pct | 100.00 | 100.00 (+0.00 pp) | 96.67 (-3.33 pp) |
| ttft_p95_ms | 17.67 | 24.37 (+37.9%) | 20.20 (+14.3%) |
| gap_p99_ms | 7.54 | 9.03 (+19.7%) | 8.99 (+19.3%) |
| goodput_rps | 6.00 | 6.00 (-0.0%) | 5.80 (-3.3%) |

All offered: **252**; completed: **252**; boundary/guard requests retained: **0**.

No recovery window qualified under the declared criteria.

Failed checks:

- recovery: normal-SLO compliance %: 96.67; required >= 99.00.
- recovery: ttft_p95_ms: 20.20; required <= 19.43.
- recovery: gap_p99_ms: 8.99; required <= 8.29.
- recovery: qualifying window starts within seconds: N/A; required <= 5.00.

Evidence in bundle: `01-baseline/report.txt`, `01-baseline/config.json`, `01-baseline/requests.jsonl`.

## combined-path-delay

**FAIL**. Fault: `{"action": "delay", "delay_ms": 100, "direction": "response", "seed": 42, "target": "*"}`

Normal serving SLO: **FAIL**; legacy acceptance: **FAIL**.

Frozen fault contract: `{"body_bytes_bound": 4110, "budget_basis": "Normal contract; attributable upstream failures may fail over.", "cancellation_ms": 500, "deadline_slack_ms": 100, "fault_slo": {"gap_ms": 100.0, "total_ms": 2000.0, "ttft_ms": 250.0}, "frame_bytes_bound": 256, "http_overhead_bytes_bound": 1024, "quiet_ms": 0, "scenario": "combined-path-delay", "version": 2}`

| Metric | Healthy | Fault (change) | Recovery (change) |
|---|---:|---:|---:|
| completion_pct | 100.00 | 100.00 (+0.00 pp) | 100.00 (+0.00 pp) |
| compliance_pct | 97.92 | 93.06 (-4.86 pp) | 94.96 (-2.96 pp) |
| ttft_p95_ms | 20.70 | 459.71 (+2121.4%) | 162.63 (+685.9%) |
| gap_p99_ms | 9.08 | 12.54 (+38.1%) | 9.05 (-0.3%) |
| goodput_rps | 5.95 | 5.59 (-6.1%) | 5.65 (-5.0%) |

All offered: **252**; completed: **252**; boundary/guard requests retained: **13**.

Recovery stability window starts +1.00s after removal; confirmed +6.00s (30 requests). This is not node restart time.

Failed checks:

- healthy: normal-SLO compliance %: 97.92; required >= 99.00.
- fault: added TTFT p95 ms: 439.02; required <= 350.00.
- fault: gap versus healthy: 12.54; required <= 11.35.
- recovery: normal-SLO compliance %: 94.96; required >= 99.00.
- recovery: ttft_p95_ms: 162.63; required <= 22.76.

Evidence in bundle: `02-combined-path-delay/report.txt`, `02-combined-path-delay/config.json`, `02-combined-path-delay/requests.jsonl`.

## fleet-stall

**FAIL**. Fault: `{"action": "stall", "direction": "response", "seed": 42, "target": "*"}`

Normal serving SLO: **FAIL**; legacy acceptance: **FAIL**.

Frozen fault contract: `{"body_bytes_bound": 4110, "budget_basis": "Normal contract; attributable upstream failures may fail over.", "cancellation_ms": 500, "deadline_slack_ms": 100, "fault_slo": {"gap_ms": 100.0, "total_ms": 2000.0, "ttft_ms": 250.0}, "frame_bytes_bound": 256, "http_overhead_bytes_bound": 1024, "quiet_ms": 0, "scenario": "fleet-stall", "version": 2}`

| Metric | Healthy | Fault (change) | Recovery (change) |
|---|---:|---:|---:|
| completion_pct | 100.00 | 0.00 (-100.00 pp) | 99.16 (-0.84 pp) |
| compliance_pct | 95.83 | 0.00 (-95.83 pp) | 97.48 (+1.65 pp) |
| ttft_p95_ms | 83.66 | N/A (N/A) | 20.07 (-76.0%) |
| gap_p99_ms | 9.19 | N/A (N/A) | 9.01 (-1.9%) |
| goodput_rps | 5.82 | 0.00 (-100.0%) | 5.80 (-0.3%) |

All offered: **252**; completed: **178**; boundary/guard requests retained: **14**.

Recovery stability window starts +0.25s after removal; confirmed +5.25s (30 requests). This is not node restart time.

Failed checks:

- healthy: normal-SLO compliance %: 95.83; required >= 99.00.
- recovery: normal-SLO compliance %: 97.48; required >= 99.00.

Evidence in bundle: `03-fleet-stall/report.txt`, `03-fleet-stall/config.json`, `03-fleet-stall/requests.jsonl`.

## slow-client-upload

**FAIL**. Fault: `{"action": "bandwidth", "direction": "request", "rate_bytes_s": 100, "seed": 42, "target": "client"}`

Normal serving SLO: **FAIL**; legacy acceptance: **FAIL**.

Frozen fault contract: `{"body_bytes_bound": 4110, "budget_basis": "Normal contract; attributable upstream failures may fail over.", "cancellation_ms": 500, "deadline_slack_ms": 100, "fault_slo": {"gap_ms": 100.0, "total_ms": 2000.0, "ttft_ms": 250.0}, "frame_bytes_bound": 256, "http_overhead_bytes_bound": 1024, "quiet_ms": 0, "scenario": "slow-client-upload", "version": 2}`

| Metric | Healthy | Fault (change) | Recovery (change) |
|---|---:|---:|---:|
| completion_pct | 100.00 | 9.72 (-90.28 pp) | 95.80 (-4.20 pp) |
| compliance_pct | 95.83 | 1.39 (-94.44 pp) | 89.92 (-5.92 pp) |
| ttft_p95_ms | 74.26 | 1956.11 (+2534.2%) | 227.14 (+205.9%) |
| gap_p99_ms | 8.86 | 12.53 (+41.4%) | 8.87 (+0.1%) |
| goodput_rps | 5.82 | 0.08 (-98.6%) | 5.35 (-8.1%) |

All offered: **252**; completed: **182**; boundary/guard requests retained: **13**.

Recovery stability window starts +2.25s after removal; confirmed +7.25s (30 requests). This is not node restart time.

Failed checks:

- recovery: completion %: 95.80; required >= 99.00.
- healthy: normal-SLO compliance %: 95.83; required >= 99.00.
- recovery: normal-SLO compliance %: 89.92; required >= 99.00.
- recovery: goodput: 5.35; required >= 5.53.
- recovery: ttft_p95_ms: 227.14; required <= 81.68.
- request deadline overruns: 1.00; required <= 0.00.

Evidence in bundle: `04-slow-client-upload/report.txt`, `04-slow-client-upload/config.json`, `04-slow-client-upload/requests.jsonl`.

## Reproduction boundaries

The recipe, order, seed and report calculation are fixed. Regenerating from unchanged saved evidence with this source produces identical Markdown/JSON. Fresh TCP runs will have different timing samples because of CPU scheduling, buffering and TCP chunking; a seed does not make live networking deterministic. Compare distributions and verdicts, not bitwise-equal live timings. Each scenario here is one run, not a confidence interval.

The pre-fault deadline guard and control-boundary exclusions are explicit; those requests are still in all-offered totals. Inter-output events are not necessarily individual tokens. No natural failure likelihood, EC2 performance or GPU throughput is inferred.
