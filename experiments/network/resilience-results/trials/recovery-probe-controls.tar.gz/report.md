# Network failure scenario report

Contract v2: resilience acceptance is separate from the unchanged normal serving SLO and legacy acceptance checks. A resilience PASS never erases failed requests.

Source: `dfee96b5660de567c000723159190b4eeb59c9da`. Environment: Linux-7.0.12-linuxkit-aarch64-with-glibc2.39; Python 3.12.3. Seed: **42**.

Workload: **3 workers, 6.0 RPS, concurrency 32, 512 input / 16 output events**. Phases: 10s healthy → 12s fault → 20s recovery. Scenarios execute sequentially with fresh processes.

Timing source: **model-derived**. Settings: `{"backend": "vllm", "backend_version": "0.24.0", "batch_size": 1, "model": "meta-llama/Meta-Llama-3.1-8B", "pp": 1, "system": "h100_sxm", "tp": 1}`. Model-derived schedules are estimates, not measured GPU serving. Each replay worker runs one request at a time; no continuous batching or KV-cache model.

Normal SLO: complete, TTFT ≤250.0ms, every output gap ≤100.0ms, total ≤2000.0ms. Scenario-specific resilience contracts are shown below; normal-SLO breaches remain visible.

Inputs, source files, binaries and case evidence have SHA-256 records in `suite.json`. Metrics below are recomputed from raw requests/attempts and checked against each original report.

[Recorded evidence bundle](evidence.tar.gz). Extract it to inspect the case files below or regenerate this report without running traffic.

Routing: first-output timeout 0.2s; options `{"cooldown_s": 1.0, "failure_threshold": 2, "least_inflight_retries": true, "probe_when_all_open": true}`.

## Overview

Fault-phase metrics; latency percentiles only describe received output. Failures/drops remain in completion and SLO denominators. N/A means no observed output, not zero latency.

| Scenario | Resilience | Normal SLO | Legacy contract | Completed (all offered) | Fault SLO % | Fault TTFT p95 ms | Fault gap p99 ms | Fault goodput RPS |
|---|---|---|---|---:|---:|---:|---:|---:|
| baseline | PASS | PASS | PASS | 252/252 | 100.00 | 16.96 | 8.13 | 6.00 |
| combined-path-delay | FAIL | PASS | FAIL | 252/252 | 100.00 | 219.35 | 9.57 | 5.92 |
| fleet-stall | PASS | FAIL | FAIL | 180/252 | 0.00 | N/A | N/A | 0.00 |
| slow-client-upload | PASS | FAIL | FAIL | 188/252 | 0.00 | 1999.89 | 8.60 | 0.00 |

## baseline

**PASS**. Fault: `No proxy rule.`

Normal serving SLO: **PASS**; legacy acceptance: **PASS**.

Frozen fault contract: `{"body_bytes_bound": 4110, "budget_basis": "Normal contract; attributable upstream failures may fail over.", "cancellation_ms": 500, "deadline_slack_ms": 100, "fault_slo": {"gap_ms": 100.0, "total_ms": 2000.0, "ttft_ms": 250.0}, "frame_bytes_bound": 256, "http_overhead_bytes_bound": 1024, "quiet_ms": 0, "scenario": "baseline", "version": 2}`

| Metric | Healthy | Fault (change) | Recovery (change) |
|---|---:|---:|---:|
| completion_pct | 100.00 | 100.00 (+0.00 pp) | 100.00 (+0.00 pp) |
| compliance_pct | 100.00 | 100.00 (+0.00 pp) | 100.00 (+0.00 pp) |
| ttft_p95_ms | 16.95 | 16.96 (+0.1%) | 17.25 (+1.8%) |
| gap_p99_ms | 7.74 | 8.13 (+5.1%) | 7.69 (-0.7%) |
| goodput_rps | 6.00 | 6.00 (-0.0%) | 6.00 (-0.0%) |

All offered: **252**; completed: **252**; boundary/guard requests retained: **0**.

Recovery stability window starts +0.00s after removal; confirmed +5.00s (30 requests). This is not node restart time.

All required checks passed.

Evidence in bundle: `01-baseline/report.txt`, `01-baseline/config.json`, `01-baseline/requests.jsonl`.

## combined-path-delay

**FAIL**. Fault: `{"action": "delay", "delay_ms": 100, "direction": "response", "seed": 42, "target": "*"}`

Normal serving SLO: **PASS**; legacy acceptance: **FAIL**.

Frozen fault contract: `{"body_bytes_bound": 4110, "budget_basis": "Normal contract; attributable upstream failures may fail over.", "cancellation_ms": 500, "deadline_slack_ms": 100, "fault_slo": {"gap_ms": 100.0, "total_ms": 2000.0, "ttft_ms": 250.0}, "frame_bytes_bound": 256, "http_overhead_bytes_bound": 1024, "quiet_ms": 0, "scenario": "combined-path-delay", "version": 2}`

| Metric | Healthy | Fault (change) | Recovery (change) |
|---|---:|---:|---:|
| completion_pct | 100.00 | 100.00 (+0.00 pp) | 100.00 (+0.00 pp) |
| compliance_pct | 100.00 | 100.00 (+0.00 pp) | 100.00 (+0.00 pp) |
| ttft_p95_ms | 16.61 | 219.35 (+1220.4%) | 16.86 (+1.5%) |
| gap_p99_ms | 7.61 | 9.57 (+25.7%) | 7.71 (+1.4%) |
| goodput_rps | 6.07 | 5.92 (-2.5%) | 5.95 (-2.0%) |

All offered: **252**; completed: **252**; boundary/guard requests retained: **14**.

Recovery stability window starts +0.00s after removal; confirmed +5.00s (29 requests). This is not node restart time.

Failed checks:

- fault: gap versus healthy: 9.57; required <= 9.51.

Evidence in bundle: `02-combined-path-delay/report.txt`, `02-combined-path-delay/config.json`, `02-combined-path-delay/requests.jsonl`.

## fleet-stall

**PASS**. Fault: `{"action": "stall", "direction": "response", "seed": 42, "target": "*"}`

Normal serving SLO: **FAIL**; legacy acceptance: **FAIL**.

Frozen fault contract: `{"body_bytes_bound": 4110, "budget_basis": "Normal contract; attributable upstream failures may fail over.", "cancellation_ms": 500, "deadline_slack_ms": 100, "fault_slo": {"gap_ms": 100.0, "total_ms": 2000.0, "ttft_ms": 250.0}, "frame_bytes_bound": 256, "http_overhead_bytes_bound": 1024, "quiet_ms": 0, "scenario": "fleet-stall", "version": 2}`

| Metric | Healthy | Fault (change) | Recovery (change) |
|---|---:|---:|---:|
| completion_pct | 100.00 | 0.00 (-100.00 pp) | 100.00 (+0.00 pp) |
| compliance_pct | 100.00 | 0.00 (-100.00 pp) | 100.00 (+0.00 pp) |
| ttft_p95_ms | 17.64 | N/A (N/A) | 17.49 (-0.8%) |
| gap_p99_ms | 7.80 | N/A (N/A) | 7.66 (-1.8%) |
| goodput_rps | 6.07 | 0.00 (-100.0%) | 5.95 (-2.0%) |

All offered: **252**; completed: **180**; boundary/guard requests retained: **14**.

Recovery stability window starts +0.00s after removal; confirmed +5.00s (30 requests). This is not node restart time.

All required checks passed.

Evidence in bundle: `03-fleet-stall/report.txt`, `03-fleet-stall/config.json`, `03-fleet-stall/requests.jsonl`.

## slow-client-upload

**PASS**. Fault: `{"action": "bandwidth", "direction": "request", "rate_bytes_s": 100, "seed": 42, "target": "client"}`

Normal serving SLO: **FAIL**; legacy acceptance: **FAIL**.

Frozen fault contract: `{"body_bytes_bound": 4110, "budget_basis": "Normal contract; attributable upstream failures may fail over.", "cancellation_ms": 500, "deadline_slack_ms": 100, "fault_slo": {"gap_ms": 100.0, "total_ms": 2000.0, "ttft_ms": 250.0}, "frame_bytes_bound": 256, "http_overhead_bytes_bound": 1024, "quiet_ms": 0, "scenario": "slow-client-upload", "version": 2}`

| Metric | Healthy | Fault (change) | Recovery (change) |
|---|---:|---:|---:|
| completion_pct | 100.00 | 11.11 (-88.89 pp) | 100.00 (+0.00 pp) |
| compliance_pct | 100.00 | 0.00 (-100.00 pp) | 100.00 (+0.00 pp) |
| ttft_p95_ms | 16.89 | 1999.89 (+11738.6%) | 17.15 (+1.5%) |
| gap_p99_ms | 7.63 | 8.60 (+12.8%) | 7.72 (+1.2%) |
| goodput_rps | 6.07 | 0.00 (-100.0%) | 5.95 (-2.0%) |

All offered: **252**; completed: **188**; boundary/guard requests retained: **13**.

Recovery stability window starts +0.50s after removal; confirmed +5.50s (30 requests). This is not node restart time.

All required checks passed.

Evidence in bundle: `04-slow-client-upload/report.txt`, `04-slow-client-upload/config.json`, `04-slow-client-upload/requests.jsonl`.

## Reproduction boundaries

The recipe, order, seed and report calculation are fixed. Regenerating from unchanged saved evidence with this source produces identical Markdown/JSON. Fresh TCP runs will have different timing samples because of CPU scheduling, buffering and TCP chunking; a seed does not make live networking deterministic. Compare distributions and verdicts, not bitwise-equal live timings. Each scenario here is one run, not a confidence interval.

The pre-fault deadline guard and control-boundary exclusions are explicit; those requests are still in all-offered totals. Inter-output events are not necessarily individual tokens. No natural failure likelihood, EC2 performance or GPU throughput is inferred.
