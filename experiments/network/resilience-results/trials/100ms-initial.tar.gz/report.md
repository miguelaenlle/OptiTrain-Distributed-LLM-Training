# Network failure scenario report

Contract v2: resilience acceptance is separate from the unchanged normal serving SLO and legacy acceptance checks. A resilience PASS never erases failed requests.

Source: `3bd77a6055aab1cce5bdaf82758da818ede0abb3`. Environment: Linux-7.0.12-linuxkit-aarch64-with-glibc2.39; Python 3.12.3. Seed: **42**.

Workload: **3 workers, 6.0 RPS, concurrency 32, 512 input / 16 output events**. Phases: 30.0s healthy → 30.0s fault → 60.0s recovery. Scenarios execute sequentially with fresh processes.

Timing source: **model-derived**. Settings: `{"backend": "vllm", "backend_version": "0.24.0", "batch_size": 1, "model": "meta-llama/Meta-Llama-3.1-8B", "pp": 1, "system": "h100_sxm", "tp": 1}`. Model-derived schedules are estimates, not measured GPU serving. Each replay worker runs one request at a time; no continuous batching or KV-cache model.

Normal SLO: complete, TTFT ≤250.0ms, every output gap ≤100.0ms, total ≤2000.0ms. Scenario-specific resilience contracts are shown below; normal-SLO breaches remain visible.

Inputs, source files, binaries and case evidence have SHA-256 records in `suite.json`. Metrics below are recomputed from raw requests/attempts and checked against each original report.

[Recorded evidence bundle](evidence.tar.gz). Extract it to inspect the case files below or regenerate this report without running traffic.

Routing: first-output timeout 0.1s; options `{"cooldown_s": 1.0, "failure_threshold": 1, "least_inflight_retries": true}`.

## Overview

Fault-phase metrics; latency percentiles only describe received output. Failures/drops remain in completion and SLO denominators. N/A means no observed output, not zero latency.

| Scenario | Resilience | Normal SLO | Legacy contract | Completed (all offered) | Fault SLO % | Fault TTFT p95 ms | Fault gap p99 ms | Fault goodput RPS |
|---|---|---|---|---:|---:|---:|---:|---:|
| baseline | PASS | PASS | PASS | 720/720 | 100.00 | 17.99 | 7.62 | 6.00 |
| client-delay | PASS | PASS | PASS | 720/720 | 100.00 | 119.36 | 8.46 | 6.00 |
| client-disconnect | PASS | FAIL | FAIL | 540/720 | 0.00 | 18.15 | 7.72 | 0.00 |
| client-jitter | PASS | FAIL | FAIL | 720/720 | 92.22 | 164.08 | 86.49 | 5.53 |
| combined-path-delay | FAIL | FAIL | FAIL | 538/720 | 0.00 | N/A | N/A | 0.00 |
| fleet-stall | FAIL | FAIL | FAIL | 531/720 | 0.00 | N/A | N/A | 0.00 |
| idle-expiry | PASS | FAIL | FAIL | 700/720 | 88.83 | 17.94 | 7.71 | 5.30 |
| slow-client-download | PASS | FAIL | FAIL | 720/720 | 41.34 | 68.06 | 101.04 | 2.47 |
| slow-client-upload | FAIL | FAIL | FAIL | 537/720 | 0.00 | 1684.23 | 7.61 | 0.00 |
| worker-delay | PASS | PASS | PASS | 720/720 | 100.00 | 115.76 | 7.66 | 5.97 |
| worker-flapping | INVALID | PASS | INVALID | 532/532 | 100.00 | 118.26 | 7.65 | 6.00 |
| worker-stall | NOT RUN | — | — | — | — | — | — | — |
| worker-truncate | NOT RUN | — | — | — | — | — | — | — |
| worker-unreachable | NOT RUN | — | — | — | — | — | — | — |

## baseline

**PASS**. Fault: `No proxy rule.`

Normal serving SLO: **PASS**; legacy acceptance: **PASS**.

Frozen fault contract: `{"body_bytes_bound": 4110, "budget_basis": "Normal contract; attributable upstream failures may fail over.", "cancellation_ms": 500, "deadline_slack_ms": 100, "fault_slo": {"gap_ms": 100.0, "total_ms": 2000.0, "ttft_ms": 250.0}, "frame_bytes_bound": 256, "http_overhead_bytes_bound": 1024, "quiet_ms": 0, "scenario": "baseline", "version": 2}`

| Metric | Healthy | Fault (change) | Recovery (change) |
|---|---:|---:|---:|
| completion_pct | 100.00 | 100.00 (+0.00 pp) | 100.00 (+0.00 pp) |
| compliance_pct | 100.00 | 100.00 (+0.00 pp) | 100.00 (+0.00 pp) |
| ttft_p95_ms | 17.91 | 17.99 (+0.4%) | 17.82 (-0.5%) |
| gap_p99_ms | 7.56 | 7.62 (+0.8%) | 7.58 (+0.3%) |
| goodput_rps | 6.00 | 6.00 (-0.0%) | 6.00 (-0.0%) |

All offered: **720**; completed: **720**; boundary/guard requests retained: **0**.

Recovery stability window starts +0.00s after removal; confirmed +5.00s (30 requests). This is not node restart time.

All required checks passed.

Evidence in bundle: `01-baseline/report.txt`, `01-baseline/config.json`, `01-baseline/requests.jsonl`.

## client-delay

**PASS**. Fault: `{"action": "delay", "delay_ms": 100, "direction": "response", "seed": 42, "target": "client"}`

Normal serving SLO: **PASS**; legacy acceptance: **PASS**.

Frozen fault contract: `{"body_bytes_bound": 4110, "budget_basis": "Normal contract; attributable upstream failures may fail over.", "cancellation_ms": 500, "deadline_slack_ms": 100, "fault_slo": {"gap_ms": 100.0, "total_ms": 2000.0, "ttft_ms": 250.0}, "frame_bytes_bound": 256, "http_overhead_bytes_bound": 1024, "quiet_ms": 0, "scenario": "client-delay", "version": 2}`

| Metric | Healthy | Fault (change) | Recovery (change) |
|---|---:|---:|---:|
| completion_pct | 100.00 | 100.00 (+0.00 pp) | 100.00 (+0.00 pp) |
| compliance_pct | 100.00 | 100.00 (+0.00 pp) | 100.00 (+0.00 pp) |
| ttft_p95_ms | 17.75 | 119.36 (+572.5%) | 17.76 (+0.1%) |
| gap_p99_ms | 7.62 | 8.46 (+11.0%) | 7.68 (+0.7%) |
| goodput_rps | 6.02 | 6.00 (-0.3%) | 5.98 (-0.6%) |

All offered: **720**; completed: **720**; boundary/guard requests retained: **13**.

Recovery stability window starts +0.00s after removal; confirmed +5.00s (30 requests). This is not node restart time.

All required checks passed.

Evidence in bundle: `02-client-delay/report.txt`, `02-client-delay/config.json`, `02-client-delay/requests.jsonl`.

## client-disconnect

**PASS**. Fault: `Client cancels after five nonempty output events, for fault-phase dispatches only.`

Normal serving SLO: **FAIL**; legacy acceptance: **FAIL**.

Frozen fault contract: `{"body_bytes_bound": 4110, "budget_basis": "Normal contract; attributable upstream failures may fail over.", "cancellation_ms": 500, "deadline_slack_ms": 100, "fault_slo": {"gap_ms": 100.0, "total_ms": 2000.0, "ttft_ms": 250.0}, "frame_bytes_bound": 256, "http_overhead_bytes_bound": 1024, "quiet_ms": 0, "scenario": "client-disconnect", "version": 2}`

| Metric | Healthy | Fault (change) | Recovery (change) |
|---|---:|---:|---:|
| completion_pct | 100.00 | 0.00 (-100.00 pp) | 100.00 (+0.00 pp) |
| compliance_pct | 100.00 | 0.00 (-100.00 pp) | 100.00 (+0.00 pp) |
| ttft_p95_ms | 17.12 | 18.15 (+6.0%) | 17.69 (+3.3%) |
| gap_p99_ms | 7.84 | 7.72 (-1.6%) | 7.60 (-3.0%) |
| goodput_rps | 6.00 | 0.00 (-100.0%) | 6.00 (-0.0%) |

All offered: **720**; completed: **540**; boundary/guard requests retained: **0**.

Recovery stability window starts +0.00s after removal; confirmed +5.00s (30 requests). This is not node restart time.

All required checks passed.

Evidence in bundle: `03-client-disconnect/report.txt`, `03-client-disconnect/config.json`, `03-client-disconnect/requests.jsonl`.

## client-jitter

**PASS**. Fault: `{"action": "delay", "delay_ms": 75, "direction": "response", "jitter_ms": 75, "seed": 42, "target": "client"}`

Normal serving SLO: **FAIL**; legacy acceptance: **FAIL**.

Frozen fault contract: `{"body_bytes_bound": 4110, "budget_basis": "Maximum injected delay + profiled gap + 25ms scheduling allowance, rounded up to 50ms.", "cancellation_ms": 500, "deadline_slack_ms": 100, "fault_slo": {"gap_ms": 200, "total_ms": 2000.0, "ttft_ms": 250.0}, "frame_bytes_bound": 256, "http_overhead_bytes_bound": 1024, "quiet_ms": 0, "scenario": "client-jitter", "version": 2}`

| Metric | Healthy | Fault (change) | Recovery (change) |
|---|---:|---:|---:|
| completion_pct | 100.00 | 100.00 (+0.00 pp) | 100.00 (+0.00 pp) |
| compliance_pct | 100.00 | 92.22 (-7.78 pp) | 100.00 (+0.00 pp) |
| ttft_p95_ms | 17.65 | 164.08 (+829.4%) | 17.86 (+1.2%) |
| gap_p99_ms | 7.63 | 86.49 (+1034.2%) | 7.62 (-0.1%) |
| goodput_rps | 6.02 | 5.53 (-8.1%) | 5.98 (-0.6%) |

All offered: **720**; completed: **720**; boundary/guard requests retained: **13**.

Recovery stability window starts +0.00s after removal; confirmed +5.00s (30 requests). This is not node restart time.

All required checks passed.

Evidence in bundle: `04-client-jitter/report.txt`, `04-client-jitter/config.json`, `04-client-jitter/requests.jsonl`.

## combined-path-delay

**FAIL**. Fault: `{"action": "delay", "delay_ms": 100, "direction": "response", "seed": 42, "target": "*"}`

Normal serving SLO: **FAIL**; legacy acceptance: **FAIL**.

Frozen fault contract: `{"body_bytes_bound": 4110, "budget_basis": "Normal contract; attributable upstream failures may fail over.", "cancellation_ms": 500, "deadline_slack_ms": 100, "fault_slo": {"gap_ms": 100.0, "total_ms": 2000.0, "ttft_ms": 250.0}, "frame_bytes_bound": 256, "http_overhead_bytes_bound": 1024, "quiet_ms": 0, "scenario": "combined-path-delay", "version": 2}`

| Metric | Healthy | Fault (change) | Recovery (change) |
|---|---:|---:|---:|
| completion_pct | 100.00 | 0.00 (-100.00 pp) | 99.72 (-0.28 pp) |
| compliance_pct | 100.00 | 0.00 (-100.00 pp) | 99.72 (-0.28 pp) |
| ttft_p95_ms | 17.98 | N/A (N/A) | 17.96 (-0.1%) |
| gap_p99_ms | 7.60 | N/A (N/A) | 7.67 (+0.9%) |
| goodput_rps | 6.02 | 0.00 (-100.0%) | 5.97 (-0.9%) |

All offered: **720**; completed: **538**; boundary/guard requests retained: **14**.

Recovery stability window starts +0.25s after removal; confirmed +5.25s (30 requests). This is not node restart time.

Failed checks:

- fault: completion %: 0.00; required >= 99.00.
- fault: normal-SLO compliance %: 0.00; required >= 65.00.
- fault: compliance drop (pp): 100.00; required <= 35.00.
- fault: goodput: 0.00; required >= 3.91.
- fault: TTFT p95 ms: N/A; required <= 600.00.
- fault: added TTFT p95 ms: N/A; required <= 350.00.
- fault: gap p99 ms: N/A; required <= 50.00.
- fault: gap versus healthy: N/A; required <= 9.50.

Evidence in bundle: `05-combined-path-delay/report.txt`, `05-combined-path-delay/config.json`, `05-combined-path-delay/requests.jsonl`.

## fleet-stall

**FAIL**. Fault: `{"action": "stall", "direction": "response", "seed": 42, "target": "*"}`

Normal serving SLO: **FAIL**; legacy acceptance: **FAIL**.

Frozen fault contract: `{"body_bytes_bound": 4110, "budget_basis": "Normal contract; attributable upstream failures may fail over.", "cancellation_ms": 500, "deadline_slack_ms": 100, "fault_slo": {"gap_ms": 100.0, "total_ms": 2000.0, "ttft_ms": 250.0}, "frame_bytes_bound": 256, "http_overhead_bytes_bound": 1024, "quiet_ms": 0, "scenario": "fleet-stall", "version": 2}`

| Metric | Healthy | Fault (change) | Recovery (change) |
|---|---:|---:|---:|
| completion_pct | 95.83 | 0.00 (-95.83 pp) | 99.72 (+3.89 pp) |
| compliance_pct | 94.64 | 0.00 (-94.64 pp) | 99.72 (+5.08 pp) |
| ttft_p95_ms | 19.96 | N/A (N/A) | 17.70 (-11.4%) |
| gap_p99_ms | 8.92 | N/A (N/A) | 7.59 (-14.9%) |
| goodput_rps | 5.70 | 0.00 (-100.0%) | 5.97 (+4.7%) |

All offered: **720**; completed: **531**; boundary/guard requests retained: **13**.

Recovery stability window starts +0.25s after removal; confirmed +5.25s (30 requests). This is not node restart time.

Failed checks:

- healthy: completion %: 95.83; required >= 99.00.
- healthy: normal-SLO compliance %: 94.64; required >= 99.00.

Evidence in bundle: `06-fleet-stall/report.txt`, `06-fleet-stall/config.json`, `06-fleet-stall/requests.jsonl`.

## idle-expiry

**PASS**. Fault: `{"action": "idle", "direction": "response", "idle_ms": 50, "seed": 42, "target": "worker-1"}`

Normal serving SLO: **FAIL**; legacy acceptance: **FAIL**.

Frozen fault contract: `{"body_bytes_bound": 4110, "budget_basis": "Normal contract; attributable upstream failures may fail over.", "cancellation_ms": 500, "deadline_slack_ms": 100, "fault_slo": {"gap_ms": 100.0, "total_ms": 2000.0, "ttft_ms": 250.0}, "frame_bytes_bound": 256, "http_overhead_bytes_bound": 1024, "quiet_ms": 150, "scenario": "idle-expiry", "version": 2}`

| Metric | Healthy | Fault (change) | Recovery (change) |
|---|---:|---:|---:|
| completion_pct | 100.00 | 88.83 (-11.17 pp) | 100.00 (+0.00 pp) |
| compliance_pct | 100.00 | 88.83 (-11.17 pp) | 100.00 (+0.00 pp) |
| ttft_p95_ms | 17.66 | 17.94 (+1.6%) | 17.72 (+0.3%) |
| gap_p99_ms | 7.62 | 7.71 (+1.3%) | 7.62 (+0.1%) |
| goodput_rps | 6.02 | 5.30 (-12.0%) | 5.98 (-0.6%) |

All offered: **720**; completed: **700**; boundary/guard requests retained: **14**.

Recovery stability window starts +0.00s after removal; confirmed +5.00s (30 requests). This is not node restart time.

All required checks passed.

Evidence in bundle: `07-idle-expiry/report.txt`, `07-idle-expiry/config.json`, `07-idle-expiry/requests.jsonl`.

## slow-client-download

**PASS**. Fault: `{"action": "bandwidth", "direction": "response", "rate_bytes_s": 3000, "seed": 42, "target": "client"}`

Normal serving SLO: **FAIL**; legacy acceptance: **FAIL**.

Frozen fault contract: `{"body_bytes_bound": 4110, "budget_basis": "Bounded SSE frame/HTTP bytes divided by configured bandwidth, replay timing, one pacing quantum and declared 50/100ms scheduling allowances.", "cancellation_ms": 500, "deadline_slack_ms": 100, "fault_slo": {"gap_ms": 200, "total_ms": 1950, "ttft_ms": 550}, "frame_bytes_bound": 256, "http_overhead_bytes_bound": 1024, "quiet_ms": 0, "scenario": "slow-client-download", "version": 2}`

| Metric | Healthy | Fault (change) | Recovery (change) |
|---|---:|---:|---:|
| completion_pct | 100.00 | 100.00 (+0.00 pp) | 100.00 (+0.00 pp) |
| compliance_pct | 100.00 | 41.34 (-58.66 pp) | 100.00 (+0.00 pp) |
| ttft_p95_ms | 17.38 | 68.06 (+291.6%) | 17.93 (+3.2%) |
| gap_p99_ms | 7.69 | 101.04 (+1214.6%) | 7.76 (+1.0%) |
| goodput_rps | 6.02 | 2.47 (-59.0%) | 5.98 (-0.6%) |

All offered: **720**; completed: **720**; boundary/guard requests retained: **14**.

Recovery stability window starts +0.00s after removal; confirmed +5.00s (30 requests). This is not node restart time.

All required checks passed.

Evidence in bundle: `08-slow-client-download/report.txt`, `08-slow-client-download/config.json`, `08-slow-client-download/requests.jsonl`.

## slow-client-upload

**FAIL**. Fault: `{"action": "bandwidth", "direction": "request", "rate_bytes_s": 100, "seed": 42, "target": "client"}`

Normal serving SLO: **FAIL**; legacy acceptance: **FAIL**.

Frozen fault contract: `{"body_bytes_bound": 4110, "budget_basis": "Normal contract; attributable upstream failures may fail over.", "cancellation_ms": 500, "deadline_slack_ms": 100, "fault_slo": {"gap_ms": 100.0, "total_ms": 2000.0, "ttft_ms": 250.0}, "frame_bytes_bound": 256, "http_overhead_bytes_bound": 1024, "quiet_ms": 0, "scenario": "slow-client-upload", "version": 2}`

| Metric | Healthy | Fault (change) | Recovery (change) |
|---|---:|---:|---:|
| completion_pct | 100.00 | 1.68 (-98.32 pp) | 98.33 (-1.67 pp) |
| compliance_pct | 100.00 | 0.00 (-100.00 pp) | 98.33 (-1.67 pp) |
| ttft_p95_ms | 18.04 | 1684.23 (+9238.2%) | 17.88 (-0.9%) |
| gap_p99_ms | 7.79 | 7.61 (-2.3%) | 7.69 (-1.3%) |
| goodput_rps | 6.02 | 0.00 (-100.0%) | 5.88 (-2.3%) |

All offered: **720**; completed: **537**; boundary/guard requests retained: **14**.

Recovery stability window starts +1.00s after removal; confirmed +6.00s (30 requests). This is not node restart time.

Failed checks:

- recovery: completion %: 98.33; required >= 99.00.
- recovery: normal-SLO compliance %: 98.33; required >= 99.00.

Evidence in bundle: `09-slow-client-upload/report.txt`, `09-slow-client-upload/config.json`, `09-slow-client-upload/requests.jsonl`.

## worker-delay

**PASS**. Fault: `{"action": "delay", "delay_ms": 300, "direction": "response", "seed": 42, "target": "worker-1"}`

Normal serving SLO: **PASS**; legacy acceptance: **PASS**.

Frozen fault contract: `{"body_bytes_bound": 4110, "budget_basis": "Normal contract; attributable upstream failures may fail over.", "cancellation_ms": 500, "deadline_slack_ms": 100, "fault_slo": {"gap_ms": 100.0, "total_ms": 2000.0, "ttft_ms": 250.0}, "frame_bytes_bound": 256, "http_overhead_bytes_bound": 1024, "quiet_ms": 0, "scenario": "worker-delay", "version": 2}`

| Metric | Healthy | Fault (change) | Recovery (change) |
|---|---:|---:|---:|
| completion_pct | 100.00 | 100.00 (+0.00 pp) | 100.00 (+0.00 pp) |
| compliance_pct | 100.00 | 100.00 (+0.00 pp) | 100.00 (+0.00 pp) |
| ttft_p95_ms | 17.78 | 115.76 (+551.1%) | 17.81 (+0.2%) |
| gap_p99_ms | 7.72 | 7.66 (-0.8%) | 7.73 (+0.0%) |
| goodput_rps | 6.02 | 5.97 (-0.9%) | 5.98 (-0.6%) |

All offered: **720**; completed: **720**; boundary/guard requests retained: **14**.

Recovery stability window starts +0.00s after removal; confirmed +5.00s (29 requests). This is not node restart time.

All required checks passed.

Evidence in bundle: `10-worker-delay/report.txt`, `10-worker-delay/config.json`, `10-worker-delay/requests.jsonl`.

## worker-flapping

**INVALID**. Fault: `{"action": "stall", "direction": "response", "seed": 42, "target": "worker-1"}`

Normal serving SLO: **PASS**; legacy acceptance: **INVALID**.

Frozen fault contract: `{"body_bytes_bound": 4110, "budget_basis": "Normal contract; attributable upstream failures may fail over.", "cancellation_ms": 500, "deadline_slack_ms": 100, "fault_slo": {"gap_ms": 100.0, "total_ms": 2000.0, "ttft_ms": 250.0}, "frame_bytes_bound": 256, "http_overhead_bytes_bound": 1024, "quiet_ms": 0, "scenario": "worker-flapping", "version": 2}`

| Metric | Healthy | Fault (change) | Recovery (change) |
|---|---:|---:|---:|
| completion_pct | 100.00 | 100.00 (+0.00 pp) | 100.00 (+0.00 pp) |
| compliance_pct | 100.00 | 100.00 (+0.00 pp) | 100.00 (+0.00 pp) |
| ttft_p95_ms | 17.89 | 118.26 (+560.9%) | 17.67 (-1.3%) |
| gap_p99_ms | 7.61 | 7.65 (+0.5%) | 7.60 (-0.1%) |
| goodput_rps | 6.02 | 6.00 (-0.3%) | 2.85 (-52.7%) |

All offered: **532**; completed: **532**; boundary/guard requests retained: **13**.

Recovery stability window starts +0.00s after removal; confirmed +5.00s (30 requests). This is not node restart time.

Failed checks:

- recovery: goodput: 2.85; required >= 5.72.
- resilience: router drained: 0.00; required expected 0.00.
- resilience: worker queues drained: 0.00; required expected 0.00.
- resilience: proxy connections drained: 0.00; required expected 0.00.

Execution/evidence errors:

- KeyboardInterrupt: 

Evidence in bundle: `11-worker-flapping/report.txt`, `11-worker-flapping/config.json`, `11-worker-flapping/requests.jsonl`.

## worker-stall

NOT RUN. No finding is inferred for an unexecuted scenario.

## worker-truncate

NOT RUN. No finding is inferred for an unexecuted scenario.

## worker-unreachable

NOT RUN. No finding is inferred for an unexecuted scenario.

## Reproduction boundaries

The recipe, order, seed and report calculation are fixed. Regenerating from unchanged saved evidence with this source produces identical Markdown/JSON. Fresh TCP runs will have different timing samples because of CPU scheduling, buffering and TCP chunking; a seed does not make live networking deterministic. Compare distributions and verdicts, not bitwise-equal live timings. Each scenario here is one run, not a confidence interval.

The pre-fault deadline guard and control-boundary exclusions are explicit; those requests are still in all-offered totals. Inter-output events are not necessarily individual tokens. No natural failure likelihood, EC2 performance or GPU throughput is inferred.
